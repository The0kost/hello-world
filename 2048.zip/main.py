import pygame
import config
from numberlist import Numberlist
if __name__ == "__main__":
    screen = pygame.display.set_mode(config.RESOLUTION)
    pygame.init()
    numberlist = Numberlist()
    numberlist.add_number()
    numberlist.add_number()
    running = True
    while running:
        screen.fill((255, 255, 255))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w:
                    numberlist.move(0, -1)
                    numberlist.add_number()
                if event.key == pygame.K_s:
                    numberlist.move(0, 1)
                    numberlist.add_number()
                if event.key == pygame.K_d:
                    numberlist.move(1, 0)
                    numberlist.add_number()
                if event.key == pygame.K_a:
                    numberlist.move(-1, 0)
                    numberlist.add_number()
        numberlist.draw(screen)
        pygame.display.update()
    pygame.quit()