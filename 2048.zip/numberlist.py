import pygame
import config
from random import choice
class Numberlist:
    def __init__(self):
        self.field = [["0" for _ in range(4)] for _ in range(4)]
        self.font = pygame.font.SysFont(None, 100)
    def draw(self, screen):
        for i in range(len(self.field)):
            for j in range(len(self.field[i])):
                if self.field[i][j] != "0":
                    font = self.font.render(self.field[i][j], True, (0, 0, 0))
                    font = pygame.transform.scale(font, (config.NUMBER_WIDTH, config.NUMBER_HIEGHT))
                    screen.blit(font, (i * 100, j * 100))
    def move(self, x, y):
        bool = True
        while bool:
            bool = False
            for i in range(len(self.field)):
                for j in range(len(self.field[i])):
                    if self.field[i][j] != "0":
                        if (i+x <= 3) and (i+x >= 0) and (j+y <= 3) and (j+y >= 0):
                            if self.field[i+x][j+y] == "0":
                                self.field[i+x][j+y], self.field[i][j] = self.field[i][j], "0"
                                bool = True
                            else:
                                if self.field[i][j] == self.field[i+x][j+y]:
                                    self.field[i + x][j + y], self.field[i][j] = str(int(self.field[i+x][j+y])*2), "0"
                                    bool = True
    def add_number(self):
        tmp = []
        for i in range(len(self.field)):
            for j in range(len(self.field[i])):
                if self.field[i][j] == "0":
                    tmp.append((j, i))
        n = choice(tmp)
        self.field[n[1]][n[0]] = choice(["2", "4"])

    # def background(self, n):
    #     if n